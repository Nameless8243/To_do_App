text = input("Enter a title: ")
length = len(text)

print(f"Title length is {length}")
